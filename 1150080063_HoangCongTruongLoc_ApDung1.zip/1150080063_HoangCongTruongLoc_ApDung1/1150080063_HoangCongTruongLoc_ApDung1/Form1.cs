﻿using System;
using System.Windows.Forms;

namespace _1150080063_HoangCongTruongLoc_ApDung1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // =========================
        // HÀM TÍNH USCLN & BSCNN
        // =========================
        private int USCLN(int a, int b)
        {
            // GCD với số âm/0: lấy trị tuyệt đối
            a = Math.Abs(a);
            b = Math.Abs(b);

            // Nếu cả hai đều 0 -> không xác định
            if (a == 0 && b == 0) return 0;

            // Euclid
            while (b != 0)
            {
                int r = a % b;
                a = b;
                b = r;
            }
            return a;
        }

        private long BSCNN(int a, int b)
        {
            a = Math.Abs(a);
            b = Math.Abs(b);
            if (a == 0 || b == 0) return 0; // một trong hai bằng 0 => LCM = 0

            // dùng long để tránh tràn khi a*b lớn
            long gcd = USCLN(a, b);
            return (long)a / (long)gcd * (long)b;
        }

        // Hai sự kiện CheckedChanged không cần làm gì
        private void rdoUSCLN_CheckedChanged(object sender, EventArgs e) { }
        private void rdoBSCNN_CheckedChanged(object sender, EventArgs e) { }

        // Nút Tìm
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtA.Text.Trim());
                int b = int.Parse(txtB.Text.Trim());

                if (rdoUSCLN.Checked)
                {
                    int kq = USCLN(a, b);
                    if (a == 0 && b == 0)
                        txtKetQua.Text = "USCLN: không xác định (a = b = 0)";
                    else
                        txtKetQua.Text = $"{kq}";
                }
                else if (rdoBSCNN.Checked)
                {
                    long kq = BSCNN(a, b);
                    txtKetQua.Text = $"{kq}";
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn USCLN hoặc BSCNN!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        // Nếu có nút Thoát, bắt sự kiện như sau:
        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
