﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Windows.Forms;

namespace _1150080063_HoangCongTruongLoc_AD2
{
    public partial class Form1 : Form
    {
        
        private readonly Dictionary<string, string> _pwdToGroup = new Dictionary<string, string>
        {
            ["1496"] = "Phát triển công nghệ",
            ["2673"] = "Phát triển công nghệ",
            ["7462"] = "Nghiên cứu viên",
            ["8884"] = "Thiết kế mô hình",
            ["3842"] = "Thiết kế mô hình",
            ["3383"] = "Thiết kế mô hình",
        };

        public Form1()
        {
            InitializeComponent();

            
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

                      
            btn2.Click += btn2_Click;
            
            btn4.Click += btn4_Click;
            btn5.Click += btn5_Click;
            btn6.Click += btn6_Click;
            btn7.Click += btn7_Click;
            btn8.Click += btn8_Click;
            btn9.Click += btn9_Click;

            btnClear.Click += btnClear_Click;
            btnEnter.Click += btnEnter_Click;
            btnRing.Click += btnRing_Click;

            this.Load += (s, e) =>
            {
                txtPassword.MaxLength = 4;
                txtPassword.ReadOnly = true;
                txtPassword.UseSystemPasswordChar = true;
                txtPassword.TextAlign = HorizontalAlignment.Center;

                dataGridView1.ReadOnly = true;
                dataGridView1.AllowUserToAddRows = false;
                dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
             
            };
        }
        private void AppendDigit(string d)
        {
            if (txtPassword.TextLength < 4)
                txtPassword.Text += d;
        }

        private void AddLog(string group, string result)
        {
            string time = DateTime.Now.ToString("M/d/yyyy h:mm:ss tt");
            dataGridView1.Rows.Insert(0, time, result, group);
        }

        private void CheckAndLog()
        {
            string pwd = txtPassword.Text.Trim();
            if (pwd.Length != 4)
            {
                SystemSounds.Exclamation.Play();
                MessageBox.Show("Vui lòng nhập đủ 4 số!", "Thông báo");
                return;
            }

            if (_pwdToGroup.TryGetValue(pwd, out string group))
                AddLog(group, "Chấp nhận!");
            else
                AddLog("Không có", "Từ chối!");

            txtPassword.Clear();
            SystemSounds.Asterisk.Play();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                CheckAndLog();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Escape)
            {
                txtPassword.Clear();
                e.Handled = true;
            }
            else
            {
                if (txtPassword.TextLength < 4)
                {
                    string d = null;
                    if (e.KeyCode >= Keys.D1 && e.KeyCode <= Keys.D9) d = ((int)(e.KeyCode - Keys.D0)).ToString();
                    else if (e.KeyCode >= Keys.NumPad1 && e.KeyCode <= Keys.NumPad9) d = ((int)(e.KeyCode - Keys.NumPad0)).ToString();

                    if (!string.IsNullOrEmpty(d))
                    {
                        AppendDigit(d);
                        e.Handled = true;
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e) { /* không */ }
        private void textBox4_TextChanged(object sender, EventArgs e) { /* không  */ }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { /* không */ }


        private void btn1_Click(object sender, EventArgs e) => AppendDigit("1");
        private void btn2_Click(object sender, EventArgs e) => AppendDigit("2");
        private void btn3_Click(object sender, EventArgs e) => AppendDigit("3");
        private void btn4_Click(object sender, EventArgs e) => AppendDigit("4");
        private void btn5_Click(object sender, EventArgs e) => AppendDigit("5");
        private void btn6_Click(object sender, EventArgs e) => AppendDigit("6");
        private void btn7_Click(object sender, EventArgs e) => AppendDigit("7");
        private void btn8_Click(object sender, EventArgs e) => AppendDigit("8");
        private void btn9_Click(object sender, EventArgs e) => AppendDigit("9");

        private void btnClear_Click(object sender, EventArgs e) => txtPassword.Clear();
        private void btnEnter_Click(object sender, EventArgs e) => CheckAndLog();
        private void btnRing_Click(object sender, EventArgs e) => SystemSounds.Exclamation.Play();
    }
}
